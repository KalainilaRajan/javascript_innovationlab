let numb1=10;
let num2=5;
function operators(){
    console.log("Arithmetic operator");
    console.log("Addition:",num1+num2);
    console.log("Subtraction:",num1-num2);
    console.log("mult:",num1*num2);
    console.log("Division:",num1/num2);

}S