var username="kalainila";
let age=18;
let bool=true;
let undef;
function datatypes(){
    console.log("Data type of username variable:",typeof(username));
    console.log("Data type of age variable:",typeof(age));
    console.log("Data type of bool variable:",typeof(bool));
    console.log("Data type of undef variable:",typeof(undef));
    
}
