var num1=10;
let num2=5;
const a="Sum of two numbers";
function sum(){
    console.log(a);
    console.log(num1+num2);
}
sum();
function subtraction(){
    num1=5;
    num2=3;
    console.log("Subtraction of 2 numbers:",num1-num2);
}
subtraction();