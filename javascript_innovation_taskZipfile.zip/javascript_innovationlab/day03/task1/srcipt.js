function add(a, b) {
    return a + b;
}

// Function that greets a user
function greet(name) {
    console.log("Hello, " + name + "!");
}


console.log("Sum:", add(5, 10));     
greet("Kalainila");    